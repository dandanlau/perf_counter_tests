#!/bin/bash

rm perf_results.txt
rm perf_stat_zero_non_zero.txt

# Input file containing event names
event_names_file="event_names.txt"

# Output file for result
result_file="perf_results.txt"

# Output file for zero/non-zero check
zero_non_zero_file="perf_stat_zero_non_zero.txt"

# Loop through each event name
while IFS= read -r event_name; do
    # Run perf stat for the current event name
    output=$(sudo perf stat -e "$event_name" ./a.out 2>&1)
    
    # Extract the event count
    event_count=$(echo "$output" | grep "$event_name" | awk '{print $1}')

    # Check if the event count is zero and write "zero" or "non-zero" accordingly
    if [ "$event_count" -eq 0 ]; then
        printf "%-50s: zero\n" "$event_name" >> "$zero_non_zero_file"
    else
        printf "%-50s: non-zero\n" "$event_name" >> "$zero_non_zero_file"
    fi

    # Append the line with the event name and count to the result file
    echo "$output" | grep "$event_name" >> "$result_file"
done < "$event_names_file"

echo "Performance counter stats extracted and saved to $result_file"
echo "Zero/non-zero results saved to $zero_non_zero_file"

