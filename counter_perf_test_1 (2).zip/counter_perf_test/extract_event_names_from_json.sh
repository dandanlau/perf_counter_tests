#!/bin/bash

rm event_names.csv
rm event_names.txt

# Check if jq is installed
if ! [ -x "$(command -v jq)" ]; then
  echo 'Error: jq is not installed. Please install jq (https://stedolan.github.io/jq/download/) and try again.' >&2
  exit 1
fi

# Array of JSON files
files=("branch.json" "cache.json" "core.json" "data-fabric.json" "floating-point.json" "memory.json" "other.json" "pipeline.json" "recommended.json")
#files=("branch.json" "cache.json" "core.json" "floating-point.json" "memory.json" "other.json" "pipeline.json" "recommended.json")

# CSV output file
csv_output_file="event_names.csv"

# Text output file
text_output_file="event_names.txt"

# Loop through JSON files
for file in "${files[@]}"; do
  # Parse JSON and extract EventName
  event_names=$(jq -r '.[].EventName' < "$file")
  
  # Append event names to CSV file
  echo "$event_names" | sed '/^$/d' | while IFS= read -r line; do
    if [ ! -z "$line" ] && [ "$line" != "null" ] && [ "$line" != "NULL" ]; then
      echo "$line" >> "$csv_output_file"
    fi
  done
  
  # Append event names to text file
  echo "$event_names" | sed '/^$/d' | while IFS= read -r line; do
    if [ ! -z "$line" ] && [ "$line" != "null" ] && [ "$line" != "NULL" ]; then
      echo "$line" >> "$text_output_file"
    fi
  done
done

echo "Event names extracted and saved to $csv_output_file and $text_output_file"

